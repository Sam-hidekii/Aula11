__author__ = 'Samuel Assis'
#==========================================
quant = int(input('\n\n~Informe Quantos Cigarros Você Fuma Por Dia: '))
anos = int(input('Informe por quantos anos você fuma: '))

soma = qant*(anos*365)
min = soma*10

sub = (min/60)/24

print('Você tem %.2f dias a menos de vida'%sub)

print('\n\n....................................')
#==========================================
print('\n\n~~~Calculadora de Dias de Carro Alugado~~~')

d = int(input('\nQuantos Dias o Carro Ficou Alugado: '))

k = float(input('\nQuantos Km foram rodados: ').replace(',','.'))

paga = (d*60)+(k*0.15)

print('\nO valor a ser pago é R${:.2f} devido a {:.0f} dias de aluguel e {:.0f} Km rodados'.format(paga,d,k))

print('\n\n....................................')

#==========================================
print('\n\n~~~Conversor Temperatura Celsius para Fahrenheit~~~')

c = float(input('\n\nInsira a temperatura em Celsius: ').replace(',','.'))
f = (9*(c/5)+32)
print('Fahrenheit: {:.2f}'.format(f))

print('\n''----Conversor Temperatura Fahrenheit para Celsius----')
f = float(input('\n\nInsira a temperatura em Fahrenheit: ').replace(',','.'))
c = ((f-32)/1.8)
print('Celsius: {:.2f}'.format(c))